:HL["/_next/static/css/3217dc05bb719018.css","style"]
:HL["/fonts/Biscuit Glitch.woff2","font",{"crossOrigin":"anonymous","type":"font/woff2"}]
:HL["/fonts/NotoSansArabic-VariableFont_wdth,wght.woff2","font",{"crossOrigin":"anonymous","type":"font/woff2"}]
:HL["https://fonts.googleapis.com/css2?family=Geist:wght@400;500;550;600;700&family=Geist+Mono:wght@400;500;600&display=swap","style"]
0:{"buildId":"f6cbQdVex9PTyLwDyOaMt","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"admin","paramType":null,"paramKey":"admin","hasRuntimePrefetch":false,"slots":{"children":{"name":"categories","paramType":null,"paramKey":"categories","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
