1:"$Sreact.fragment"
2:I[68172,[],""]
3:I[97210,[],""]
0:{"buildId":"I4mkMXLJN_Z3eEcncZyeq","rsc":["$","$1","c",{"children":[null,["$","div",null,{"className":"pos-root","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]]}],"loading":null,"isPartial":false}
